#pragma once
#include "genesis.h"

#define MW_RX_TX_BUFFER_SIZE 1460

void comm_megawifi_init(void);
bool comm_megawifi_is_present(void);
u8 comm_megawifi_read_ready(void);
u8 comm_megawifi_read(void);
u8 comm_megawifi_write_ready(void);
void comm_megawifi_write(const u8* data, u16 length);
void comm_megawifi_tick(void);
void comm_megawifi_midiEmitCallback(u8 data);
void comm_megawifi_send(u8 ch, char* data, u16 len);
void comm_megawifi_vsync(u16 delta);
