#include "comm_serial.h"
#include "ring_buf.h"
#include "serial.h"
#include "log.h"
#include "settings.h"
#include "user_prefs.h"

static bool recvData = false;
static u8 ring_buf_arr[512];
static ring_buf_t ring_buf;

u16 baud_rate(void)
{
    switch (serial_sctrl() & 0xC0) {
    case SCTRL_300_BPS:
        return 300;
    case SCTRL_1200_BPS:
        return 1200;
    case SCTRL_2400_BPS:
        return 2400;
    default:
        return 4800;
    }
}

static void update_buffer(void)
{
    while (serial_readyToReceive()) {
        recvData = true;

        ring_buf_status_t status = ring_buf_write(&ring_buf, serial_receive());
        if (status == RING_BUF_FULL) {
            log_warn("Serial: Buffer overflow!");
            break;
        }
    }
}

static void recv_ready_callback(void)
{
    update_buffer();
}

static void flush_rrdy(void)
{
    while (serial_readyToReceive()) {
        serial_receive();
    }
}

void comm_serial_init(void)
{
    ring_buf_init(&ring_buf, ring_buf_arr, sizeof(ring_buf_arr));
    serial_init(COMM_SERIAL_PORT, SCTRL_4800_BPS | SCTRL_SIN | SCTRL_SOUT | SCTRL_RINT);
    serial_setReadyToReceiveCallback(&recv_ready_callback);
    flush_rrdy();
    if (settings_debug_serial()) {
        log_info("Serial: Baud = %i", baud_rate());
    }
}

bool comm_serial_is_present(void)
{
    return true;
}

u8 comm_serial_read_ready(void)
{
    if (!recvData)
        return false;
    return ring_buf_can_read(&ring_buf);
}

u8 comm_serial_read(void)
{
    u8 data = 0;
    ring_buf_status_t status = ring_buf_read(&ring_buf, &data);
    if (status == RING_BUF_OK) {
        u16 bufferAvailable = ring_buf_available(&ring_buf);
        if (bufferAvailable < 32) {
            log_warn("Serial: Buffer free = %d bytes", bufferAvailable);
        }
        return data;
    }

    if (status == RING_BUF_EMPTY) {
        log_warn("Serial: Attempted read from empty buffer");
    }

    return 0;
}

u8 comm_serial_write_ready(void)
{
    return serial_readyToSend();
}

void comm_serial_write(const u8* data, u16 length)
{
    for (u16 i = 0; i < length; i++) {
        while (!comm_serial_write_ready())
            ;
        serial_send(data[i]);
    }
}
